﻿namespace JokesWebApplication.Models
{
	public class Joke
	{
        public int Id { get; set; }
        public string JokesQuestions { get; set; }
        public string JokesAnswers { get; set; }

        public Joke()
        {
            
        }
    }
}
