﻿CREATE TABLE [dbo].[Joke] (
    [Id]             INT            IDENTITY (1, 1) NOT NULL,
    [JokesQuestions] NVARCHAR (MAX) NULL,
    [JokesAnswers]   NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_Joke] PRIMARY KEY CLUSTERED ([Id] ASC)
);

